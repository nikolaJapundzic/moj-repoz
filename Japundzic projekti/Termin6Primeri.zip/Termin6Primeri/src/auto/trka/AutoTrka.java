package auto.trka;

/**
 * Created by lazar on 11.9.16..
 */
public class AutoTrka {

    public static void main(String [] args){
        AutomobilNit mitsubishi = new AutomobilNit("Mitsubishi");
        AutomobilNit ferari = new AutomobilNit("Ferarri");
        AutomobilNit jugo = new AutomobilNit("Jugic");

        mitsubishi.start();
        ferari.start();
        jugo.start();

        //TODO: Ovde napisati kod koji ceka sve automobile da zavrse i pokrece novi krug trke
    }
}
