package primer1.klase;

public class Automobil {
    boolean radi ;
    public void upali ()
    {
        radi = true ;
    }
    public void ugasi ()
    {
        radi = false ;
    }


}
