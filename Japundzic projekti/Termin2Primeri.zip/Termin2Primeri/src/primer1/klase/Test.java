package primer1.klase;

public class Test {
    public static void main ( String args []) {
        Automobil a ;
        a = new Automobil () ;
        a . upali () ;
    }
}
