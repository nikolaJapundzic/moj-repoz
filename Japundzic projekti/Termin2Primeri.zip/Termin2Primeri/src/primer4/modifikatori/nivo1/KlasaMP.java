package primer4.modifikatori.nivo1;

public class KlasaMP {

    int atributDefault;
    public int atributPublic;
    private int atributPrivate;
    protected int atributProtected;


    void metodaDefault()
    {
    }

    public void metodaPublic()
    {
    }

    private void metodaPrivate()
    {
    }

    protected void metodaProtected()
    {
    }
}
