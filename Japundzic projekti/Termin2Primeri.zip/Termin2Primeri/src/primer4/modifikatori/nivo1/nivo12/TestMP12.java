package primer4.modifikatori.nivo1.nivo12;

import primer4.modifikatori.nivo1.KlasaMP;

public class TestMP12 {
    public static void main(String[] args) {
        KlasaMP mp=new KlasaMP();

        int v1=mp.atributPublic;
        //int v2=mp.atributDefault;
        //int v3=mp.atributPrivate;
        //int v4=mp.atributProtected;
        mp.metodaPublic();
        //mp.metodaDefault();
        //mp.metodaPrivate();
        //mp.metodaProtected();
    }
}
