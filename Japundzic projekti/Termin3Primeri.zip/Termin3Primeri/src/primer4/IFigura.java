package primer4;


public interface IFigura {
    public abstract double izracunajPovrsinu();
    public abstract double izracunajObim();
}
