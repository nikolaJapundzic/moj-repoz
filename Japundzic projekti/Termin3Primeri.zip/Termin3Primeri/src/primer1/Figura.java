package primer1;

public class Figura {
    public double izracunajPovrsinu(){
        return 0;
    }

    public double izracunajObim(){
        return 0;
    }
}
