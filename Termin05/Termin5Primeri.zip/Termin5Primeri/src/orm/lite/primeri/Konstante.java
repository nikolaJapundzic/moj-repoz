package orm.lite.primeri;


public class Konstante {
    public static final String DATABASE_URL="jdbc:sqlite:restoran.db";
}
